package com.lti.FramProject.dao;

import com.lti.FarmProject.entity.BiddingPage;

public interface BiddingPageDao {
	public BiddingPage pageByRequestId(long request_id);
	public Boolean addBiddingPage(BiddingPage biddingpage);
	public Boolean updateBiddingPage(BiddingPage biddingpage);
}
