package com.lti.FramProject.dao;

import java.util.List;

import com.lti.FarmProject.entity.FarmerPlaceRequest;

public interface FramPlaceRequestDao {
	public List<FarmerPlaceRequest> getAllPlaceRequest();
	public FarmerPlaceRequest getPlaceRequestById(long requestid);
	public boolean savePlaceRequest(FarmerPlaceRequest request);
	public boolean deletePlaceRequestById(long requestid);

}
