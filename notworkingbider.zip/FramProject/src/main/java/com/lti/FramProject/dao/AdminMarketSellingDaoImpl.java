package com.lti.FramProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.AdminMarketSelling;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
//import com.lti.FarmProject.entity.FarmerPlaceRequest;
@Repository("AdminMarketSellingDao")
public class AdminMarketSellingDaoImpl extends AbstractDao<Long,  AdminMarketSelling> implements  AdminMarketSellingDao{

	@Override
	public List<AdminMarketSelling> getAllMarketSelling() {
		@SuppressWarnings("unchecked")
		List<AdminMarketSelling> list=getEntityManager().createQuery("SELECT u FROM AdminMarketSelling u ").getResultList();
		return list;
	}

	@Override
	public AdminMarketSelling getMarketSellingById(long marketid) {
		AdminMarketSelling ams=(AdminMarketSelling) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarketSelling u WHERE u.marketid LIKE :Id")
		        .setParameter("Id",marketid)
		        .getSingleResult();
				return ams;
	}

	@Override
	public boolean saveMarketSelling(AdminMarketSelling marketsell) {
		persist(marketsell);
		return true;
	}

	@Override
	public boolean deleteMarketSellingById(long marketid) {
		AdminMarketSelling ams=(AdminMarketSelling) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarketSelling u WHERE u.marketid LIKE :Id")
		        .setParameter("Id",marketid)
		        .getSingleResult();
		delete(ams);
		return true;
	}

	

}
