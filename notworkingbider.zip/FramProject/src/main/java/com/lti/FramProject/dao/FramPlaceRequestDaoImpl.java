package com.lti.FramProject.dao;

import java.util.List;


import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.AdminMarket;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
@Repository("FramPlaceRequestDao")
public class FramPlaceRequestDaoImpl extends AbstractDao<Long,  FarmerPlaceRequest> implements FramPlaceRequestDao{

	//@Override
	public List<FarmerPlaceRequest> getAllPlaceRequest() {
		// TODO Auto-generated method stub
		List<FarmerPlaceRequest> list=getEntityManager().createQuery("SELECT u FROM FarmerPlaceRequest u ").getResultList();
		return list;
	}

//	@Override
	public FarmerPlaceRequest getPlaceRequestById(long requestid) {
		// TODO Auto-generated method stub
		FarmerPlaceRequest fpr=(FarmerPlaceRequest) getEntityManager()
		        .createQuery("SELECT u FROM FarmerPlaceRequest u WHERE u.requestid LIKE :Id")
		        .setParameter("Id",requestid)
		        .getSingleResult();
				return fpr;
	}

	//@Override
	public boolean savePlaceRequest(FarmerPlaceRequest request) {
		persist(request);
		return true;
	}

	//@Override
	public boolean deletePlaceRequestById(long requestid) {
		FarmerPlaceRequest fpr=(FarmerPlaceRequest) getEntityManager()
		        .createQuery("SELECT u FROM FarmerPlaceRequest u WHERE u.requestid LIKE :Id")
		        .setParameter("Id",requestid)
		        .getSingleResult();
		delete(fpr);
		return true;
	}

}
