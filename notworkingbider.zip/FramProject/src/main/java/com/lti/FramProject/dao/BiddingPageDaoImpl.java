package com.lti.FramProject.dao;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.BiddingPage;

@Repository("BiddingPageDao")
public class BiddingPageDaoImpl extends AbstractDao<Long, BiddingPage> implements BiddingPageDao {

	
	public BiddingPage pageByRequestId(long request_id) {
		// TODO Auto-generated method stub
		BiddingPage bp=(BiddingPage)  getEntityManager()
                .createQuery("SELECT u FROM BiddingPage u WHERE u.bid_requestid LIKE :Id")
                .setParameter("Id",request_id)
                .getSingleResult();
		return bp;
	}

	
	public Boolean addBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		persist(biddingpage);
		return true;
	}

	
	public Boolean updateBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		getEntityManager().createQuery("UPDATE BiddingPage SET u.current_bid:cb WHERE u.bid_id'"
		+biddingpage.getBid_id()+"'").setParameter("cb",biddingpage.getBid_your_amount());
		
		/*EntityManager em = getEntityManager();
		em.getTransaction().begin();
		BiddingPage bp=em.find(BiddingPage.class, biddingpage.getBid_id());
		bp.setCurrent_bid(biddingpage.getBid_your_amount());
		em.getTransaction().commit();*/
		return true;
	}

}
