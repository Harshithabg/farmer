 package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.entity.AdminMarketSelling;
import com.lti.FramProject.dao.AdminMarketSellingDao;


@Service
@Transactional
public class AdminMarketSellingServiceImp implements AdminMarketSellingService{
	private AdminMarketSellingDao dao;
	public AdminMarketSellingServiceImp() {		
	}

@Autowired
public  AdminMarketSellingServiceImp( AdminMarketSellingDao dao) {
	super();
	this.dao = dao;
}


public List<AdminMarketSelling> getAllMarketSelling() {
	List<AdminMarketSelling> list = new ArrayList<AdminMarketSelling>();
	list=dao.getAllMarketSelling();
	return list;
}


public AdminMarketSelling getMarketSellingById(long marketid) {
	AdminMarketSelling request = dao.getMarketSellingById(marketid);
	return request;
}


public boolean saveMarketSelling(AdminMarketSelling marketsell) {
	try {
		dao.saveMarketSelling(marketsell);
		return true;
	}catch(Exception ex) {
		return false;
	}
}


public boolean deleteMarketSellingById(long marketid) {
	try {
		dao.deleteMarketSellingById(marketid);
		return true;
	}catch(Exception ex) {
		return false;
	}
}



}
