package com.lti.FarmProject.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Bidder")
public class Bidder {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bidder-seq")
	@SequenceGenerator(name="bidder-seq",sequenceName="bid_seq",allocationSize=1)
	long bidder_id;
	String Bidder_name;
	long contact_no;
	String email;
	String Address;
	String city;
	String state;
	long pin_code;
	long account_no;
	String ifsc;
	Boolean adhar_status;
	Boolean pan_status;
	Boolean trader_lisence;
	String password;
	
	public Bidder() {
		super();
	}
	
	public Bidder(String bidder_name, long contact_no, String email, String address, String city, String state,
			long pin_code, long account_no, String ifsc) {
		super();
		Bidder_name = bidder_name;
		this.contact_no = contact_no;
		this.email = email;
		Address = address;
		this.city = city;
		this.state = state;
		this.pin_code = pin_code;
		this.account_no = account_no;
		this.ifsc = ifsc;
	}

	public long getBidder_id() {
		return bidder_id;
	}
	public void setBidder_id(long bidder_id) {
		this.bidder_id = bidder_id;
	}
	public String getBidder_name() {
		return Bidder_name;
	}
	public void setBidder_name(String bidder_name) {
		Bidder_name = bidder_name;
	}
	public long getContact_no() {
		return contact_no;
	}
	public void setContact_no(long contact_no) {
		this.contact_no = contact_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getPin_code() {
		return pin_code;
	}
	public void setPin_code(long pin_code) {
		this.pin_code = pin_code;
	}
	public long getAccount_no() {
		return account_no;
	}
	public void setAccount_no(long account_no) {
		this.account_no = account_no;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public Boolean getAdhar_status() {
		return adhar_status;
	}
	public void setAdhar_status(Boolean adhar_status) {
		this.adhar_status = adhar_status;
	}
	public Boolean getPan_status() {
		return pan_status;
	}
	public void setPan_status(Boolean pan_status) {
		this.pan_status = pan_status;
	}
	public Boolean getTrader_lisence() {
		return trader_lisence;
	}
	public void setTrader_lisence(Boolean trader_lisence) {
		this.trader_lisence = trader_lisence;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Bidder [bidder_id=" + bidder_id + ", Bidder_name=" + Bidder_name + ", contact_no=" + contact_no
				+ ", email=" + email + ", Address=" + Address + ", city=" + city + ", state=" + state + ", pin_code="
				+ pin_code + ", account_no=" + account_no + ", ifsc=" + ifsc + ", adhar_status=" + adhar_status
				+ ", pan_status=" + pan_status + ", trader_lisence=" + trader_lisence + ", password=" + password + "]";
	}
	
	
	
}