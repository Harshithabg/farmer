package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.entity.FarmerPlaceRequest;
//import com.lti.FarmProject.repository.FarmPlaceRequestRepository;
import com.lti.FramProject.dao.FramPlaceRequestDao;

@Service
@Transactional
public class FarmPlaceRequestServiceImp implements FarmPlaceRequestService {

	//private FarmPlaceRequestRepository repository;
	private FramPlaceRequestDao dao;
	public FarmPlaceRequestServiceImp() {}
		
	
	@Autowired
	public FarmPlaceRequestServiceImp(FramPlaceRequestDao dao) {
		super();
		this.dao = dao;
	}
	
	public FarmerPlaceRequest getPlaceRequestById(long requestid) {
		FarmerPlaceRequest request = dao.getPlaceRequestById(requestid);
		return request;
	}

	public List<FarmerPlaceRequest> getAllPlaceRequest() {
		List<FarmerPlaceRequest> list = new ArrayList<FarmerPlaceRequest>();
		list=dao.getAllPlaceRequest();
		return list;
		
	}

	

	public boolean savePlaceRequest(FarmerPlaceRequest fr) {
		try {
			dao.savePlaceRequest(fr);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	public boolean deletePlaceRequestById(long requestid) {
		try {
			dao.deletePlaceRequestById(requestid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}


	


	

}
