package com.lti.FarmProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.BiddingPage;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.service.BiddingPageService;
import com.lti.FarmProject.service.FarmPlaceRequestService;

@Controller
public class BidderController {
	private BiddingPageService service;
	private FarmPlaceRequestService userService;
	
	public BidderController() {
		super();
	}

	@Autowired
	public BidderController(BiddingPageService service, FarmPlaceRequestService userService) {
		super();
		this.service = service;
		this.userService = userService;
	}
	
	@RequestMapping(value="/addbidding",method=RequestMethod.GET)
	public ModelAndView getBindingPage(){
		ModelAndView mv=new ModelAndView("biddinghome");
		List<FarmerPlaceRequest> sellreq= userService.getAllPlaceRequest();
		mv.addObject("sellreq",sellreq);
		return mv;
	}
	

	@RequestMapping(value="/savebidding",method=RequestMethod.POST)
	public ModelAndView postBindingPage(@ModelAttribute BiddingPage biddingpage,BindingResult result){
		ModelAndView mv=new ModelAndView("redirect:/bidderhome");
		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		long cb=biddingpage.getCurrent_bid();
		if(cb==0){
		boolean isAdded = service.addBiddingPage(biddingpage);
		if (isAdded) {
			System.out.println(biddingpage);
			mv.addObject("message", "Applied successfully");
			
		} else {
			return new ModelAndView("error");
		}
		//mv.addObject("bidding",new BiddingPage());
		
		}else{
			service.updateBiddingPage(biddingpage);
		}
		return mv;
	}
	@RequestMapping(value="/getpagebyid/{requestid}",method=RequestMethod.GET)
	public ModelAndView getPageOnRequest(@PathVariable Long requestid){
		ModelAndView mv=new ModelAndView("biddingpage");
		FarmerPlaceRequest fp=userService.getPlaceRequestById(requestid);
		BiddingPage biddingpage=new BiddingPage();
		biddingpage.setBid_crop_name(fp.getCropname());
		biddingpage.setSelling_req(fp);
		biddingpage.setBid_crop_type(fp.getCrop_type());
		biddingpage.setBid_price(fp.getPrice());
		mv.addObject("biddingpage",biddingpage);
		
		return mv;
		
	}
	/*
	@RequestMapping(value="/getpagebyid/{requestid}",method=RequestMethod.POST)
	public ModelAndView postPageOnRequest(@ModelAttribute FarmerPlaceRequest request,BindingResult result){
		ModelAndView mv=new ModelAndView("");
		
		return mv;
		
	}*/
}
