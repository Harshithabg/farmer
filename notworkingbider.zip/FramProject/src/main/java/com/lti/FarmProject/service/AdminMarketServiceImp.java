package com.lti.FarmProject.service;

import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.entity.AdminMarket;

//import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FramProject.dao.AdminMarketDao;
//import com.lti.FramProject.dao.FramPlaceRequestDao;

@Service
@Transactional
public class AdminMarketServiceImp implements AdminMarketService {
	
private AdminMarketDao dao;
public AdminMarketServiceImp() {}

@Autowired
public  AdminMarketServiceImp(AdminMarketDao dao) {
	super();
	this.dao = dao;
}



public List<AdminMarket> getAllMarket() {
	List<AdminMarket> list = new ArrayList<AdminMarket>();
	list=dao.getAllMarket();
	return list;
}


public AdminMarket getMarketById(long marketid) {
	AdminMarket request = dao.getMarketById(marketid);
	return request;
}


public boolean saveMarket(AdminMarket market) {
	try {
		dao.saveMarket(market);
		return true;
	}catch(Exception ex) {
		return false;
	}
}


public boolean deleteMarketById(long marketid) {
	try {
		dao.deleteMarketById(marketid);
		return true;
	}catch(Exception ex) {
		return false;
	}
}
	
	
}
