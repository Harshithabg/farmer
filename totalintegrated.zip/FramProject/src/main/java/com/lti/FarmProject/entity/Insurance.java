package com.lti.FarmProject.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="farmer_insurance")
public class Insurance {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="policy-seq")
	@SequenceGenerator(name="policy-seq",sequenceName="policy_seq",allocationSize=1)
	long policy_no;
	String company_name;
	String fullname;
	int year;
	String season;
	long sum_insured;
	String crop_name;
	float area;
	long share_premium;
	long premium_amount;
	double sum_perhectare;
	public Insurance() {
		super();
	}

	public Insurance(String fullname, int year, String season, long sum_insured, String crop_name, float area) {
		super();
		this.fullname = fullname;
		this.year = year;
		this.season = season;
		this.sum_insured = sum_insured;
		this.crop_name = crop_name;
		this.area = area;
	}

	public Insurance(String fullname, int year, String season, long sum_insured, String crop_name, float area,
			long share_premium, long premium_amount) {
		super();
		this.fullname = fullname;
		this.year = year;
		this.season = season;
		this.sum_insured = sum_insured;
		this.crop_name = crop_name;
		this.area = area;
		this.share_premium = share_premium;
		this.premium_amount = premium_amount;
	}
	
	public Insurance(String fullname, int year, String season, long sum_insured, String crop_name, float area,long share_premium, long premium_amount, double sum_perhectare) {
		super();
		this.fullname = fullname;
		this.year = year;
		this.season = season;
		this.sum_insured = sum_insured;
		this.crop_name = crop_name;
		this.area = area;
		this.share_premium = share_premium;
		this.premium_amount = premium_amount;
		this.sum_perhectare = sum_perhectare;
	}

	public long getPolicy_no() {
		return policy_no;
	}

	public void setPolicy_no(long policy_no) {
		this.policy_no = policy_no;
	}
	
	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	public double getSum_perhectare() {
		return sum_perhectare;
	}

	public void setSum_perhectare(double sum_perhectare) {
		this.sum_perhectare = sum_perhectare;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}

	public long getSum_insured() {
		return sum_insured;
	}

	public void setSum_insured(long sum_insured) {
		this.sum_insured = sum_insured;
	}

	public String getCrop_name() {
		return crop_name;
	}

	public void setCrop_name(String crop_name) {
		this.crop_name = crop_name;
	}

	public float getArea() {
		return area;
	}

	public void setArea(float area) {
		this.area = area;
	}

	public long getShare_premium() {
		return share_premium;
	}

	public void setShare_premium(long share_premium) {
		this.share_premium = share_premium;
	}

	public long getPremium_amount() {
		return premium_amount;
	}

	public void setPremium_amount(long premium_amount) {
		this.premium_amount = premium_amount;
	}

	@Override
	public String toString() {
		return "Insurance [policy_no=" + policy_no + ", fullname=" + fullname + ", year=" + year + ", season=" + season
				+ ", sum_insured=" + sum_insured + ", crop_name=" + crop_name + ", area=" + area + ", share_premium="
				+ share_premium + ", premium_amount=" + premium_amount + ", sum_perhectare=" + sum_perhectare + "]";
	}
	
}
