package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.FarmerPlaceRequest;

@Repository("FramerPlaceRequestDao")
public class FarmerPlaceRequestImp extends AbstractDao<Long,FarmerPlaceRequest> implements FarmerPlaceRequestDao {

	
	public List<FarmerPlaceRequest> getAllPlaceRequest() {
		@SuppressWarnings("unchecked")
		List<FarmerPlaceRequest> list=getEntityManager().createQuery("SELECT u FROM FarmerPlaceRequest u ").getResultList();
		return list;
	}

	
	public FarmerPlaceRequest getPlaceRequestById(Long requestid) {
		FarmerPlaceRequest fpr=(FarmerPlaceRequest) getEntityManager()
		        .createQuery("SELECT u FROM FarmerPlaceRequest u WHERE u.requestid LIKE :Id")
		        .setParameter("Id",requestid)
		        .getSingleResult();
				return fpr;
	}

	
	public boolean savePlaceRequest(FarmerPlaceRequest request) {
		persist(request);
		return true;
	}

	
	public boolean deletePlaceRequestById(Long requestid) {
		FarmerPlaceRequest fpr=(FarmerPlaceRequest) getEntityManager()
		        .createQuery("SELECT u FROM FarmerPlaceRequest u WHERE u.requestid LIKE :Id")
		        .setParameter("Id",requestid)
		        .getSingleResult();
		delete(fpr);
		return true;
	}


	@Override
	public Boolean updatePlaceRequestById(FarmerPlaceRequest request) {
		try{
			getEntityManager().merge(request);
		}catch(Exception e){
			return false;
		}
		return true;
	}

}
