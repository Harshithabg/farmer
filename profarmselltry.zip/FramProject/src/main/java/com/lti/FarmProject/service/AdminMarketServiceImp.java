package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.entity.AdminMarket;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.repository.AdminMarketRepository;
import com.lti.FarmProject.repository.FarmPlaceRequestRepository;


@Service
@Transactional
public class AdminMarketServiceImp implements AdminMarketService {
private AdminMarketRepository repository;
	
	public AdminMarketServiceImp() {
		
	}
	@Autowired
	public AdminMarketServiceImp(AdminMarketRepository repository) {
		super();
		this.repository = repository;
	}
	
	@Override
	public List<AdminMarket> getAllMarket() {
		List<AdminMarket> list = new ArrayList<AdminMarket>();
		repository.findAll().forEach(e -> list.add(e));
		return list;
		
	}

	@Override
	public AdminMarket getMarketById(Long marketid) {
		AdminMarket market =  repository.findById(marketid).get();
		return market;
	}

	@Override
	public boolean saveMarket(AdminMarket market) {
		try {
			repository.save(market);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteMarketById(Long marketid) {
		try {
			repository.deleteById(marketid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

}
