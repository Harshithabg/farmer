package com.lti.FarmProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.AdminMarketSelling;

import com.lti.FarmProject.service.AdminMarketSellingService;



@Controller
public class AdminMarketSellingController {
	private AdminMarketSellingService userService;

	public AdminMarketSellingController() {

	}
	@Autowired
	public AdminMarketSellingController(AdminMarketSellingService userService) {
		this.userService = userService;
	}
	
	@RequestMapping(value = { "/", "/adminsell" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminhome");
		return mv;
	}
	
	@RequestMapping(value = "/allMarketSellings", method = RequestMethod.POST)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView("addMarketSelling");
		List<AdminMarketSelling> userList = userService.getAllMarketSelling();
		mv.addObject("userList", userList);
		mv.setViewName("allMarketSellings");
		return mv;
	}
	
	@RequestMapping(value = "/addMarketSelling", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("addMarketSelling");
		mv.addObject("headerMessage", "Add User Details");
		mv.addObject("marketsell", new AdminMarketSelling());
		return mv;
	}

	@RequestMapping(value = "/addMarketSelling", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute AdminMarketSelling marketsell, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminhome");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = userService.saveMarketSelling(marketsell);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	}
	@RequestMapping(value = "/editMarketSelling/{marketid}", method = RequestMethod.GET)
	public ModelAndView displayEditUserForm(@PathVariable Long marketid) {
		ModelAndView mv = new ModelAndView("/editMarketSelling");
		AdminMarketSelling marketsell = userService.getMarketSellingById(marketid);
		mv.addObject("headerMessage", "Edit User Details");
		mv.addObject("marketsell", marketsell);
		return mv;
	}

	@RequestMapping(value = "/editMarketSelling/{marketid}", method = RequestMethod.POST)
	public ModelAndView saveEditedUser(@ModelAttribute AdminMarketSelling marketsell, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");

		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		boolean isSaved = userService.saveMarketSelling(marketsell);
		if (!isSaved) {

			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/deleteMarketSelling/{marketid}", method = RequestMethod.GET)
	public ModelAndView deleteUserById(@PathVariable Long marketid) {
		boolean isDeleted = userService.deleteMarketSellingById(marketid);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/adminsell");
		return mv;

	}

}
