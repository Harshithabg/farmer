package com.lti.FarmProject.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.FarmProject.entity.AdminMarket;

public interface AdminMarketRepository  extends 
CrudRepository<AdminMarket, Long> {


}
