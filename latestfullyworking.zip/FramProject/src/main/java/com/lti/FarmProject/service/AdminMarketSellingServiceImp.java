package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.dao.AdminMarketDao;
import com.lti.FarmProject.dao.AdminMarketSellingDao;
import com.lti.FarmProject.entity.AdminMarket;
import com.lti.FarmProject.entity.AdminMarketSelling;



@Service
@Transactional
public class AdminMarketSellingServiceImp implements AdminMarketSellingService{
	@Autowired
	private AdminMarketSellingDao dao;
	@Autowired
	private AdminMarketDao adao;
	
	public AdminMarketSellingServiceImp() {
		
	}
	
	public AdminMarketSellingServiceImp(AdminMarketSellingDao dao) {
		super();
		this.dao = dao;
	}
	
	public AdminMarketSellingServiceImp(AdminMarketDao adao) {
		super();
		this.adao = adao;
	}

	@Override
	public List<AdminMarketSelling> getAllMarketSelling() {
		List<AdminMarketSelling> list = new ArrayList<AdminMarketSelling>();
		list=dao.getAllMarketSelling();
		return list;
	}

	@Override
	public AdminMarketSelling getMarketSellingById(Long marketid) {
		AdminMarketSelling marketsell =  dao.getMarketSellingById(marketid);
		return marketsell;
	}

	@Override
	public boolean saveMarketSelling(AdminMarketSelling marketsell) {
		try {
			String loc=marketsell.getLocation();
			AdminMarket a=adao.getMarketByLoc(loc);
			long marketid=a.getMarketid();
			marketsell.setMarketid(marketid);
			System.out.println(marketsell);
			dao.saveMarketSelling(marketsell);
			System.out.println("added successfully");
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteMarketSellingById(Long marketid) {
		try {
			dao.deleteMarketSellingById(marketid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}
	@Override
	public Boolean updateMarketSellingById(AdminMarketSelling marketsell) {
		Boolean stat=dao.updateMarketSellingById(marketsell);
		return stat;
	}

}
