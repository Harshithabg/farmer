package com.lti.FarmProject.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="place_request6")
public class FarmerPlaceRequest {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="placereq-seq")
	@SequenceGenerator(name="placereq-seq",sequenceName="placereq_seq",allocationSize=1)
	private long requestid;
	private String cropname;
	private String crop_type;
	private String fertilizer_type;
	private long quantity;
	private long price;
	public long getRequestid() {
		return requestid;
	}
	public void setRequestid(long requestid) {
		this.requestid = requestid;
	}
	public String getCropname() {
		return cropname;
	}
	public void setCropname(String cropname) {
		this.cropname = cropname;
	}
	public String getCrop_type() {
		return crop_type;
	}
	public void setCrop_type(String crop_type) {
		this.crop_type = crop_type;
	}
	public String getFertilizer_type() {
		return fertilizer_type;
	}
	public void setFertilizer_type(String fertilizer_type) {
		this.fertilizer_type = fertilizer_type;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "FarmerPlaceRequest [requestid=" + requestid + ", cropname=" + cropname + ", crop_type=" + crop_type
				+ ", fertilizer_type=" + fertilizer_type + ", quantity=" + quantity + ", price=" + price + "]";
	}
	
}
