package com.lti.FarmProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.AdminMarketSelling;
import com.lti.FarmProject.entity.BiddingPage;
import com.lti.FarmProject.entity.Claim;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.service.BiddingPageService;
import com.lti.FarmProject.service.ClaimService;
import com.lti.FarmProject.service.FarmerPlaceRequestService;

@Controller
public class AdminController {
	@Autowired
	private BiddingPageService service;
	@Autowired
	private FarmerPlaceRequestService userService;
	@Autowired
	private ClaimService cs;
	
	public AdminController() {
		super();
	}

	public AdminController(BiddingPageService service) {
		super();
		this.service = service;
	}
	
	public AdminController(ClaimService cs) {
		super();
		this.cs = cs;
	}

	public AdminController(FarmerPlaceRequestService userService) {
		super();
		this.userService = userService;
	}
	long req_id;
	BiddingPage bidding;
	FarmerPlaceRequest fpm;
	@RequestMapping(value="/adminbids",method=RequestMethod.GET)
	public ModelAndView getBindingPage(){
		ModelAndView mv=new ModelAndView("adminbiddingdetails");
		List<BiddingPage> sellreq= service.getallbids();
		mv.addObject("sellreq",sellreq);
		return mv;
	}
	@RequestMapping(value = "/allsellreq", method = RequestMethod.GET)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<FarmerPlaceRequest> userList = userService.getAllPlaceRequest();
		mv.addObject("userList", userList);
		mv.setViewName("adminsellreq");
		return mv;
	}
	@RequestMapping(value = { "/adminhome1" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminhome1");
		return mv;
	}
	@RequestMapping(value={"/claimdetails"},method=RequestMethod.GET)
	public ModelAndView claims(){
		ModelAndView mv=new ModelAndView("adminclaimdetails");
		List<Claim> cl=cs.getAllClaims();
		//mv.addObject("claims", claims);
		System.out.println(cl);
		mv.addObject("claims", cl);
		mv.setViewName("adminclaimdetails");
		return mv;
	}
	@RequestMapping(value = "/approveclaims/{policy_no}", method = RequestMethod.GET)
	public ModelAndView getclaimForm(@PathVariable Long policy_no) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");
		Claim c=cs.getClaimForm(policy_no);
		
		//c.setApproval_status(true);
		cs.updateclaim(c, true);
		mv.addObject("headerMessage", "Edit User Details");
		mv.addObject("claims", c);
		return mv;
	}

/*	@RequestMapping(value = "/approveclaims/{policy_no}", method = RequestMethod.POST)
	public ModelAndView saveEditedUser(@ModelAttribute Claim c, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");

		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		
		try{
			boolean isSaved = cs.updateclaim(c, true);
		}catch(Exception e){
			return new ModelAndView("error");
		}


		return mv;
	}*/
	@RequestMapping(value = "/deleteclaims/{policy_no}", method = RequestMethod.GET)
	public ModelAndView deleteclaimById(@PathVariable long policy_no) {
		boolean isDeleted = cs.deleteclaim(policy_no);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/adminsell");
		return mv;

	}
	@RequestMapping(value="/finalise/{bid_id}",method = RequestMethod.GET)
	public ModelAndView finalisebids(@PathVariable long bid_id){
		ModelAndView mv=new ModelAndView("adminhome1");
		BiddingPage b=service.getbidbyid(bid_id);
		b.setFinalbid(true);
		service.updateBiddingPage(b);
		mv.setViewName("adminhome1");
		return mv;
		
	}
}

