package com.lti.FarmProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.AdminMarket;
import com.lti.FarmProject.service.AdminMarketService;


@Controller
public class AdminMarketController {
	private AdminMarketService userService;

	public AdminMarketController() {

	}
	@Autowired
	public AdminMarketController(AdminMarketService userService) {
		this.userService = userService;
	}


	@RequestMapping(value = { "/", "/adminhome" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminhome1");
		return mv;
	}
	
	@RequestMapping(value = "/allMarkets", method = RequestMethod.GET)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<AdminMarket> userList = userService.getAllMarket();
		mv.addObject("userList", userList);
		mv.setViewName("allMarkets");
		return mv;
	}

	@RequestMapping(value = "/addMarket", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("addMarket");
		mv.addObject("headerMessage", "Add Market Details");
		mv.addObject("market", new AdminMarket());
		return mv;
	}

	@RequestMapping(value = "/addMarket", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute AdminMarket market, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminhome");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = userService.saveMarket(market);
		if (isAdded) {
			mv.addObject("message", "New Market successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/editMarket/{marketid}", method = RequestMethod.GET)
	public ModelAndView displayEditUserForm(@PathVariable Long marketid) {
		ModelAndView mv = new ModelAndView("/editMarket");
		AdminMarket market = userService.getMarketById(marketid);
		mv.addObject("headerMessage", "Edit Market Details");
		mv.addObject("market", market);
		return mv;
	}

	@RequestMapping(value = "/editMarket/{marketid}", method = RequestMethod.POST)
	public ModelAndView saveEditedUser(@ModelAttribute AdminMarket market, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminhome1");
		
		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		boolean isSaved = userService.updateMarketById(market);
		if (!isSaved) {

			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/deleteMarket/{marketid}", method = RequestMethod.GET)
	public ModelAndView deleteUserById(@PathVariable Long marketid) {
		boolean isDeleted = userService.deleteMarketById(marketid);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/adminhome");
		return mv;

	}
}
