package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.Bidder;


@Repository("BidderDao")
public class BidderDaoImp extends AbstractDao<Long, Bidder> implements BidderDao{

	@Override
	public List<Bidder> getAllBidders() {
		@SuppressWarnings("unchecked")
		List<Bidder> list=getEntityManager().createQuery("SELECT u FROM Bidder u ").getResultList();
		return list;
	}

	@Override
	public Bidder getBiddersById(Long bidder_id) {
		Bidder fpr=(Bidder) getEntityManager()
		        .createQuery("SELECT u FROM Bidder u WHERE u.bidder_id LIKE :Id")
		        .setParameter("Id",bidder_id)
		        .getSingleResult();
				return fpr;
	}

	@Override
	public boolean saveBidders(Bidder bidder) {
		persist(bidder);
		return true;
	}

	@Override
	public boolean deleteBiddersById(Long bidder_id) {
		Bidder fpr=(Bidder) getEntityManager()
		        .createQuery("SELECT u FROM Bidder u WHERE u.bidder_id LIKE :Id").setParameter("Id",bidder_id)
		        .getSingleResult();
		delete(fpr);
		return true;
	}

	@Override
	public Boolean verifybidderrbyId(long id, String password) {
		try{
			 getEntityManager()
		        .createQuery("SELECT u FROM Bidder u WHERE u.bidder_id LIKE :Id AND u.bpassword").setParameter("Id", id)
		        .getSingleResult();
			 return true;
		}catch(Exception e)
		{
			return false;
		}
		
	}

}
