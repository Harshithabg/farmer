package com.lti.farmerAPI.Dao;

import org.springframework.stereotype.Repository;

import com.lti.farmerAPI.entity.BidderRegister;

@Repository("BidderRegisterDao")
public class BidderRegisterDaoImp extends AbstractDao<Long,  BidderRegister> implements BidderRegisterDao {

	@Override
	public boolean saveBidderRegister(BidderRegister bidderRegister) {
		
		persist(bidderRegister);
		return true;
	}

}
