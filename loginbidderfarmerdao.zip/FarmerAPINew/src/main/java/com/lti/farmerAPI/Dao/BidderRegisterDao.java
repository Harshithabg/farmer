package com.lti.farmerAPI.Dao;

import com.lti.farmerAPI.entity.BidderRegister;

public interface BidderRegisterDao {
	public boolean saveBidderRegister(BidderRegister bidderRegister);
}
