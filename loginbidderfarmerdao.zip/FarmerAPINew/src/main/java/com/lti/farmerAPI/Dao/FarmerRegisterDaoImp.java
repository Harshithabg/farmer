package com.lti.farmerAPI.Dao;


import org.springframework.stereotype.Repository;

import com.lti.farmerAPI.entity.FarmerRegister;
@Repository("FarmerRegisterDao")
public class FarmerRegisterDaoImp extends AbstractDao<Long,  FarmerRegister> implements FarmerRegisterDao{

	@Override
	public boolean saveFarmerRegister(FarmerRegister farmerRegister) {
		persist(farmerRegister);
		return true;
	}

}
