package com.lti.farmerAPI.Dao;

import com.lti.farmerAPI.entity.FarmerRegister;

public interface FarmerRegisterDao {
	public boolean saveFarmerRegister(FarmerRegister farmerRegister);
}
