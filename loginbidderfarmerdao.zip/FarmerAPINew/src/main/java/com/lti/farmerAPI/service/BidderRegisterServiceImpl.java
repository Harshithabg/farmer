package com.lti.farmerAPI.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.farmerAPI.Dao.BidderRegisterDao;
import com.lti.farmerAPI.entity.BidderRegister;


@Service
@Transactional
public class BidderRegisterServiceImpl implements  BidderRegisterService{
	
		private BidderRegisterDao dao;
		
		public BidderRegisterServiceImpl() {
			
		}
		
		@Autowired
		public BidderRegisterServiceImpl(BidderRegisterDao dao) {
			super();
			this.dao = dao;
		}
		
		
		
		@Override
	public boolean saveBidderRegister(BidderRegister bidderRegister) {
			try {
				dao.saveBidderRegister(bidderRegister);
				return true;
			}catch(Exception ex) {
				return false;
			}
	}

	

}
