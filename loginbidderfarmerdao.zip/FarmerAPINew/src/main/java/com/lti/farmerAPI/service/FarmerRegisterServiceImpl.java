package com.lti.farmerAPI.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.farmerAPI.Dao.FarmerRegisterDao;
import com.lti.farmerAPI.entity.FarmerRegister;


@Service
@Transactional
public class FarmerRegisterServiceImpl implements FarmerRegisterService{
	
			private FarmerRegisterDao dao;
			
			public FarmerRegisterServiceImpl() {
				
			}
			
			@Autowired
			public FarmerRegisterServiceImpl(FarmerRegisterDao dao) {
				super();
				this.dao = dao;
			}
			
			
			public boolean saveFarmerRegister(FarmerRegister farmerRegister) {
				try {
					dao.saveFarmerRegister(farmerRegister);
					return true;
				}catch(Exception ex) {
					return false;
				}
		}

		

	}


