package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.dao.AdminMarketSellingDao;
import com.lti.FarmProject.entity.AdminMarketSelling;



@Service
@Transactional
public class AdminMarketSellingServiceImp implements AdminMarketSellingService{
	private AdminMarketSellingDao dao;
	public AdminMarketSellingServiceImp() {
		
	}
	@Autowired
	public AdminMarketSellingServiceImp(AdminMarketSellingDao dao) {
		super();
		this.dao = dao;
	}
	
	@Override
	public List<AdminMarketSelling> getAllMarketSelling() {
		List<AdminMarketSelling> list = new ArrayList<AdminMarketSelling>();
		list=dao.getAllMarketSelling();
		return list;
	}

	@Override
	public AdminMarketSelling getMarketSellingById(Long marketid) {
		AdminMarketSelling marketsell =  dao.getMarketSellingById(marketid);
		return marketsell;
	}

	@Override
	public boolean saveMarketSelling(AdminMarketSelling marketsell) {
		try {
			dao.saveMarketSelling(marketsell);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteMarketSellingById(Long marketid) {
		try {
			dao.deleteMarketSellingById(marketid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

}
