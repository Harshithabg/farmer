package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.dao.FarmerPlaceRequestDao;
import com.lti.FarmProject.entity.FarmerPlaceRequest;


@Service
@Transactional
public class FarmerPlaceRequestServiceImp implements FarmerPlaceRequestService {

	private FarmerPlaceRequestDao dao;
	
	public FarmerPlaceRequestServiceImp() {
		
	}
	
	@Autowired
	public FarmerPlaceRequestServiceImp(FarmerPlaceRequestDao dao) {
		super();
		this.dao = dao;
	}
	public List<FarmerPlaceRequest> getAllPlaceRequest() {
		List<FarmerPlaceRequest> list = new ArrayList<FarmerPlaceRequest>();
		list=dao.getAllPlaceRequest();
		return list;
		
	}

	public FarmerPlaceRequest getPlaceRequestById(Long requestid) {
		FarmerPlaceRequest request =  dao.getPlaceRequestById(requestid);
		return request;
	}

	public boolean savePlaceRequest(FarmerPlaceRequest fr) {
		try {
			dao.savePlaceRequest(fr);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	public boolean deletePlaceRequestById(Long requestid) {
		try {
			dao.deletePlaceRequestById(requestid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

}
