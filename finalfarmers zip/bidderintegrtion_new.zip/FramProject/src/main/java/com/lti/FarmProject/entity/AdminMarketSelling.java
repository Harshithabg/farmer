package com.lti.FarmProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import javax.persistence.Table;

@Entity
@Table(name="marketselling23")
public class AdminMarketSelling {
	@Id
	@Column(name = "marketid")
	private long marketid;
	@Column(name = "cropname")
	private String cropname;
	@Column(name = "msp")
	private long msp;
	@OneToOne
	@JoinColumn(name ="marketid")
	private AdminMarket market1;
	public long getMarketid() {
		return marketid;
	}
	public void setMarketid(long marketid) {
		this.marketid = marketid;
	}
	public String getCropname() {
		return cropname;
	}
	public void setCropname(String cropname) {
		this.cropname = cropname;
	}
	public long getMsp() {
		return msp;
	}
	public void setMsp(long msp) {
		this.msp = msp;
	}
	public AdminMarket getMarket1() {
		return market1;
	}
	public void setMarket1(AdminMarket market1) {
		this.market1 = market1;
	}
	public AdminMarketSelling(long marketid, String cropname, long msp, AdminMarket market1) {
		super();
		this.marketid = marketid;
		this.cropname = cropname;
		this.msp = msp;
		this.market1 = market1;
	}
	public AdminMarketSelling(){}
	@Override
	public String toString() {
		return "AdminMarketSelling [marketid=" + marketid + ", cropname=" + cropname + ", msp=" + msp + ", market1="
				+ market1 + "]";
	}
	
	
	
}
