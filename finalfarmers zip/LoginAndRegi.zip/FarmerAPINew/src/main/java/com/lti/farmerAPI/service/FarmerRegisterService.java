package com.lti.farmerAPI.service;

import com.lti.farmerAPI.entity.FarmerRegister;

public interface FarmerRegisterService {
	public boolean saveFarmerRegister(FarmerRegister farmerRegister);

}
