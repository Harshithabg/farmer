package com.lti.farmerAPI.service;

import com.lti.farmerAPI.entity.BidderRegister;

public interface BidderRegisterService {
	public boolean saveBidderRegister(BidderRegister bidderRegister);
}
