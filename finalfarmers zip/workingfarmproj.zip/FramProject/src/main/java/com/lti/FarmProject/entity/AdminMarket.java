package com.lti.FarmProject.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.OneToOne;

import javax.persistence.Table;

@Entity
@Table(name="market22")
public class AdminMarket {
	@Id
	@Column(name = "marketid")
	private long marketid;
	
	@Column(name = "location")
	private String location;
	
	@OneToOne(mappedBy = "market1", cascade = CascadeType.ALL)
	private AdminMarketSelling selling;
	public AdminMarket(){}
	public AdminMarket(long marketid, String location) {
		super();
		this.marketid = marketid;
		this.location = location;
	}
	public long getMarketid() {
		return marketid;
	}
	public void setMarketid(long marketid) {
		this.marketid = marketid;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public AdminMarketSelling getSelling() {
		return selling;
	}
	public void setSelling(AdminMarketSelling selling) {
		this.selling = selling;
	}
	@Override
	public String toString() {
		return "AdminMarket [marketid=" + marketid + ", location=" + location + "]";
	}
	
	
}
