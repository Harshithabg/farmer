package com.lti.FarmProject.dao;

import java.util.List;

import com.lti.FarmProject.entity.AdminMarket;

public interface AdminMarketDao {
	public List<AdminMarket> getAllMarket();
	public AdminMarket getMarketById(Long marketid);
	public boolean saveMarket(AdminMarket market);
	public boolean deleteMarketById(Long marketid);
}
