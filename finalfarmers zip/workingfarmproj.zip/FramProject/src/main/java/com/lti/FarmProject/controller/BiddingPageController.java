package com.lti.FarmProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.BiddingPage;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.service.BiddingPageService;
import com.lti.FarmProject.service.FarmerPlaceRequestService;

@Controller
public class BiddingPageController {
	@Autowired
	private BiddingPageService service;
	@Autowired
	private FarmerPlaceRequestService userService;
	
	public BiddingPageController() {
		super();
	}

	public BiddingPageController(BiddingPageService service) {
		super();
		this.service = service;
	}
	
	public BiddingPageController(FarmerPlaceRequestService userService) {
		super();
		this.userService = userService;
	}
	long req_id;
	BiddingPage biddingpage;
	FarmerPlaceRequest fpm;
	@RequestMapping(value="/addbidding",method=RequestMethod.GET)
	public ModelAndView getBindingPage(){
		ModelAndView mv=new ModelAndView("bidderhome");
		List<FarmerPlaceRequest> sellreq= userService.getAllPlaceRequest();
		mv.addObject("sellreq",sellreq);
		return mv;
	}
	
	@RequestMapping(value="/savebidding",method=RequestMethod.POST)
	public ModelAndView postBindingPage(@ModelAttribute BiddingPage biddingpage, BindingResult result){
		ModelAndView mv=new ModelAndView("redirect:/bidderhome");
		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		long cb=biddingpage.getCurrent_bid();
		long bid=biddingpage.getBid_your_amount();
		if(cb==0){
		boolean isAdded = service.addBiddingPage(biddingpage);
		if (isAdded) {
			System.out.println(biddingpage);
			mv.addObject("message", "Applied successfully");
			
		} else {
			return new ModelAndView("error");
		}
		//mv.addObject("bidding",new BiddingPage());
		
		}else{
			if(cb<bid){
			service.updateBiddingPage(biddingpage);
			}else{
				System.out.println("not highest bid made");
			}
			}
		return mv;
	}
	@RequestMapping(value="/gotopagebyid",method=RequestMethod.GET)
	public ModelAndView getPageOnRequest(){  	//@ModelAttribute BiddingPage biddingpage, BindingResult result
		ModelAndView mv=new ModelAndView("biddingpage");
		System.out.println("inside getpagebyid"+fpm);
		 String cropname=fpm.getCropname();
		 long q=fpm.getQuantity();
		 String croptype=fpm.getCrop_type();
		 long price=fpm.getPrice();
		 System.out.println(cropname);
		biddingpage.setBid_crop_name(cropname);
		
		biddingpage.setBid_crop_type(croptype);
		
		biddingpage.setBid_price(price);
		
		biddingpage.setBid_quantity(q);
		service.addBiddingPage(biddingpage);
		mv.addObject("biddingpage",biddingpage);
		
		return mv;
		
	}
	@RequestMapping(value = "/editpage/{requestid}", method = RequestMethod.GET)
	public ModelAndView displayEditUserForm(@PathVariable long requestid) {
		ModelAndView mv = new ModelAndView("redirect:/gotopagebyid");
		FarmerPlaceRequest request = userService.getPlaceRequestById(requestid);
		
		fpm=request;
		System.out.println(fpm);
		//mv.addObject("headerMessage", "Edit User Details");
		//mv.addObject("biddingpage", biddingpage);
		//mv.setViewName("getpagebyid");
		return mv;
	}	

	/*
	@RequestMapping(value="/getpagebyid/{requestid}",method=RequestMethod.POST)
	public ModelAndView postPageOnRequest(@ModelAttribute FarmerPlaceRequest request,BindingResult result){
		ModelAndView mv=new ModelAndView("");
		
		return mv;
		
	}*/
}
