package com.lti.FarmProject.repository;

import org.springframework.data.repository.CrudRepository;

import com.lti.FarmProject.entity.AdminMarketSelling;

public interface AdminMarketSellingRepository extends 
CrudRepository<AdminMarketSelling, Long> {


}