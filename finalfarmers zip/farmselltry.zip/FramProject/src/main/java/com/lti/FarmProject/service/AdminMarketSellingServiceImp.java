package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.lti.FarmProject.entity.AdminMarketSelling;
import com.lti.FarmProject.repository.AdminMarketSellingRepository;


@Service
@Transactional
public class AdminMarketSellingServiceImp implements AdminMarketSellingService{
	private AdminMarketSellingRepository repository;
	public AdminMarketSellingServiceImp() {
		
	}
	@Autowired
	public AdminMarketSellingServiceImp(AdminMarketSellingRepository repository) {
		super();
		this.repository = repository;
	}
	
	@Override
	public List<AdminMarketSelling> getAllMarketSelling() {
		List<AdminMarketSelling> list = new ArrayList<AdminMarketSelling>();
		repository.findAll().forEach(e -> list.add(e));
		return list;
	}

	@Override
	public AdminMarketSelling getMarketSellingById(Long marketid) {
		AdminMarketSelling marketsell =  repository.findById(marketid).get();
		return marketsell;
	}

	@Override
	public boolean saveMarketSelling(AdminMarketSelling marketsell) {
		try {
			repository.save(marketsell);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteMarketSellingById(Long marketid) {
		try {
			repository.deleteById(marketid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

}
