package com.lti.FarmProject.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.FarmerPlaceRequest;

@Repository
public interface FarmPlaceRequestRepository extends 
CrudRepository<FarmerPlaceRequest, Long> {

	

}
