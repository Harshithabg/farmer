package farmerinsurance.dao;

import java.util.List;

import farmerinsurance.entity.Claim;

public interface ClaimDao {
	public Boolean addClaim(Claim claim);
	public Boolean getClaimStatus(long policy_no);
	public Claim getClaimForm(long policy_no);
	public List<Claim> getAllClaims();

}
