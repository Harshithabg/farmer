package farmerinsurance.dao;

import java.util.List;

import farmerinsurance.entity.Claim;
//import farmerinsurance.entity.Claim;
import farmerinsurance.entity.Insurance;


public interface InsuranceDao{
	public List<Insurance> getAllInsurances();
	public Insurance getInsuranceByPolicy(long policy_no);
	public Boolean saveInsurance(Insurance insurance);
	public Boolean deleteInsuranceByPolicy(long policy_no);
	
}


