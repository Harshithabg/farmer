package farmerinsurance.respository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import farmerinsurance.entity.Insurance;


public interface InsuranceRepository extends CrudRepository<Insurance, Long>{

	
}
