package farmerinsurance.service;

import java.util.List;

import farmerinsurance.entity.Claim;

public interface ClaimService {
	public Boolean addClaim(Claim claim);
	public Boolean getClaimStatus(long policy_no);
	public Claim getClaimForm(long policy_no);
	public List<Claim> getAllClaims();
}
