package farmerinsurance.service;

import java.util.List;

//import farmerinsurance.entity.Claim;
import farmerinsurance.entity.Insurance;

public interface InsuranceService {
	public List<Insurance> getAllInsurances();
	public Insurance getInsuranceByPolicy(long policy_no);
	public Boolean saveInsurance(Insurance insurance);
	public Boolean deleteInsuranceByPolicy(long policy_no);
	//public Boolean addClaim(Claim claim);
	//public Boolean getClaimStatus(long policy_no);
	//public Claim getClaimForm(long policy_no);
	//public List<Claim> getAllClaims();
}
