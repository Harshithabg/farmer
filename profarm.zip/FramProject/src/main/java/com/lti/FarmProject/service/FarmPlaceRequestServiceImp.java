package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.repository.FarmPlaceRequestRepository;

@Service
@Transactional
public class FarmPlaceRequestServiceImp implements FarmPlaceRequestService {

	private FarmPlaceRequestRepository repository;
	
	public FarmPlaceRequestServiceImp() {
		
	}
	
	@Autowired
	public FarmPlaceRequestServiceImp(FarmPlaceRequestRepository repository) {
		super();
		this.repository = repository;
	}
	public List<FarmerPlaceRequest> getAllPlaceRequest() {
		List<FarmerPlaceRequest> list = new ArrayList<FarmerPlaceRequest>();
		repository.findAll().forEach(e -> list.add(e));
		return list;
		
	}

	public FarmerPlaceRequest getPlaceRequestById(Long requestid) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean savePlaceRequest(FarmerPlaceRequest request) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deletePlaceRequestById(Long requestid) {
		// TODO Auto-generated method stub
		return false;
	}

}
