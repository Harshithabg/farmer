package com.lti.FarmProject.service;

import java.util.List;

import com.lti.FarmProject.entity.FarmerPlaceRequest;

public interface FarmPlaceRequestService {
	public List<FarmerPlaceRequest> getAllPlaceRequest();
	public FarmerPlaceRequest getPlaceRequestById(Long requestid);
	public boolean savePlaceRequest(FarmerPlaceRequest request);
	public boolean deletePlaceRequestById(Long requestid);
}
