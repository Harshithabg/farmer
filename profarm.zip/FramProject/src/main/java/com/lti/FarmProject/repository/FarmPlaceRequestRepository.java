package com.lti.FarmProject.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FarmPlaceRequestRepository extends 
CrudRepository<FarmPlaceRequestRepository, Long> {

}
