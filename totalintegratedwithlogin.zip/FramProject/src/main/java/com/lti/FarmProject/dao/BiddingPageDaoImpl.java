package com.lti.FarmProject.dao;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.BiddingPage;
@Repository("BiddingPageDao")
public class BiddingPageDaoImpl extends AbstractDao<Long,BiddingPage> implements BiddingPageDao{

	//@Override
	public BiddingPage pageByRequestId(long request_id) {
		// TODO Auto-generated method stub
		BiddingPage bp=(BiddingPage) getEntityManager()
                .createQuery("SELECT u FROM BiddingPage u WHERE u.bid_requestid LIKE :Id")
                .setParameter("Id",request_id)
                .getSingleResult();
		return bp;
	}

	//@Override
	public Boolean addBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		persist(biddingpage);
		return true;
	}

	//@Override
	public Boolean updateBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		getEntityManager().merge(biddingpage);
		return true;
	}

}
