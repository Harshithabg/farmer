package com.lti.FarmProject.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.BidderLogin;
import com.lti.FarmProject.entity.Farmer;
import com.lti.FarmProject.entity.FarmerLogin;
import com.lti.FarmProject.service.FarmerService;

@Controller
public class FarmerController {
	@Autowired
	private FarmerService service;
	
	@RequestMapping(value={"/farmerlogin" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("farmerlogin");
		return mv;
}
	@RequestMapping(value={"/verifyfarmer" }, method = RequestMethod.POST)
	public ModelAndView verify(@RequestParam("farmer_id") long id, @RequestParam("fpassword") String password){
		//ModelAndView mv = new ModelAndView();
		Farmer f=service.getFarmersById(id);
		String pass=f.getFpassword();

		if(password.equals(pass)){
			ModelAndView mv = new ModelAndView("farmerhome");
			mv.setViewName("farmerhome");
			return mv;
		}else{
			System.out.println("invalid user or password");
			ModelAndView mv1 = new ModelAndView("redirect:/farmerlogin");
			//mv.setViewName("redirect:/farmerlogin");
			return mv1;
		}
		//return mv;
}
	@RequestMapping(value={"/FarmerRegister"},method=RequestMethod.GET)
	public ModelAndView farmerForm()  {
		ModelAndView mv=new ModelAndView("farmerform");
		mv.addObject("farmer", new Farmer());
		return mv;
		
	}
	@RequestMapping(value={"/saveFarmerRegister"},method=RequestMethod.POST)
	public ModelAndView savefarmerForm(@ModelAttribute Farmer farmer,BindingResult result)  {
		ModelAndView mv=new ModelAndView("farmerlogin");
		//mv.addObject("farmer", new Farmer());
		service.saveFarmers(farmer);	
		return mv;	
	}
	@RequestMapping(value={"/forgotfarmerpassword"},method=RequestMethod.POST)
	public ModelAndView updatefarmerForm(@ModelAttribute Farmer farmer,BindingResult result)  {
		ModelAndView mv=new ModelAndView("farmerlogin");
		//mv.addObject("farmer", new Farmer());
		service.saveFarmers(farmer);	
		return mv;	
	}
}
