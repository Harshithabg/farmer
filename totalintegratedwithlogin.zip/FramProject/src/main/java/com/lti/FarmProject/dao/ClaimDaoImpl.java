package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.Claim;


@Repository("ClaimDao")
public class ClaimDaoImpl extends AbstractDao<Long, Claim> implements ClaimDao{

	//@Override
	public Boolean addClaim(Claim claim) {
		// TODO Auto-generated method stub
		persist(claim);
		return true;
	}

	//@Override
	public Boolean getClaimStatus(long policy_no) {
		// TODO Auto-generated method stub
		Claim claim=(Claim) getEntityManager()
                .createQuery("SELECT u FROM Claim u WHERE u.policy_no LIKE :Id")
                .setParameter("Id",policy_no)
                .getSingleResult();
		Boolean status=claim.getApproval_status();
		return status;
	}

	//@Override
	public Claim getClaimForm(long policy_no) {
		// TODO Auto-generated method stub
		Claim claim=(Claim) getEntityManager()
                .createQuery("SELECT u FROM Claim u WHERE u.policy_no LIKE :Id")
                .setParameter("Id",policy_no)
                .getSingleResult();
		return claim;
	}

	//@Override
	public List<Claim> getAllClaims() {
		// TODO Auto-generated method stub
		List<Claim> cl=getEntityManager().createQuery("SELECT u FROM Claim u ").getResultList();
		return cl;
	}
	
}
