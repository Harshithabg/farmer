package com.lti.FarmProject.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.Bidder;
import com.lti.FarmProject.entity.BidderLogin;
import com.lti.FarmProject.entity.Farmer;
import com.lti.FarmProject.service.BidderService;

@Controller
public class BidderController {
	@Autowired
	private BidderService service;
	

	public BidderController(BidderService service) {
		super();
		this.service = service;
	}
	
	@RequestMapping(value={"/bidderlogin" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bidderlogin");
		return mv;
}
	@RequestMapping(value={"/bidderverify" }, method = RequestMethod.GET)
	public ModelAndView verify(@RequestParam("bidder_id") long id, @RequestParam("bpassword") String password){
	//	ModelAndView mv = new ModelAndView();
		Bidder f=service.getBiddersById(id);
		String pass=f.getBpassword();
		if(password.equals(pass)){
			ModelAndView mv = new ModelAndView("continue");
			mv.setViewName("continue");
			
			return mv;
		}else{
			System.out.println("invalid user or password");
			ModelAndView mv1 = new ModelAndView("redirect:/bidderlogin");
		//	mv.setViewName("bidderlogin");
			return mv1;
		}
		//return mv;
}
	@RequestMapping(value={"/BidderRegister"},method=RequestMethod.GET)
	public ModelAndView BidderForm()  {
		ModelAndView mv=new ModelAndView("bidderform");
		mv.addObject("bidder", new Bidder());
		return mv;
		
	}
	@RequestMapping(value={"/saveBidderRegister"},method=RequestMethod.POST)
	public ModelAndView saveBidderForm(@ModelAttribute Bidder bidder,BindingResult result)  {
		ModelAndView mv=new ModelAndView("bidderlogin");
		//mv.addObject("farmer", new Farmer());
		service.saveBidders(bidder)	;
		return mv;
		
	}
	@RequestMapping(value={"/forgotbidderpassword"},method=RequestMethod.POST)
	public ModelAndView updateBidderForm(@ModelAttribute Bidder bidder,BindingResult result)  {
		ModelAndView mv=new ModelAndView("bidderlogin");
		//mv.addObject("farmer", new Farmer());
		service.saveBidders(bidder)	;
		return mv;
		
	}
}