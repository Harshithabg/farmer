package com.lti.FarmProject.dao;

import java.util.List;

import com.lti.FarmProject.entity.Bidder;


public interface BidderDao {
	public List<Bidder> getAllBidders();
	public Bidder getBiddersById(Long bidder_id);
	public boolean saveBidders(Bidder bidder);
	public boolean deleteBiddersById(Long bidder_id);
	public Boolean verifybidderrbyId(long id,String password);
}
