package com.lti.FarmProject.service;

import java.util.List;

import com.lti.FarmProject.entity.Claim;
public interface ClaimService {
	public Boolean addClaim(Claim claim);
	public Boolean getClaimStatus(long policy_no);
	public Claim getClaimForm(long policy_no);
	public List<Claim> getAllClaims();
}
