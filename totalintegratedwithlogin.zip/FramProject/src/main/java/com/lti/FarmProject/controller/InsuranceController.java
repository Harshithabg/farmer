package com.lti.FarmProject.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.Claim;
import com.lti.FarmProject.entity.Insurance;
import com.lti.FarmProject.service.ClaimService;
import com.lti.FarmProject.service.InsuranceService;




@Controller
public class InsuranceController {
	
	public InsuranceService insuranceservice;
	public ClaimService claimservice;
	public InsuranceController(){
		
	}
	@Autowired
	public InsuranceController(InsuranceService insuranceservice, ClaimService claimservice) {
		super();
		this.insuranceservice = insuranceservice;
		this.claimservice = claimservice;
	}
	@RequestMapping(value = { "/", "/ihome" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView("inshome");
		mv.setViewName("inshome");
		return mv;
	}
	
	Insurance i=new Insurance();
	@RequestMapping(value="/addInsurance",method=RequestMethod.GET)
	public ModelAndView displaynewform(){
		ModelAndView mv = new ModelAndView("addInsurance");
		mv.addObject("headerMessage", "Apply for Insurance");
		mv.addObject("insurance", new Insurance());
		return mv;
	}
	
	@RequestMapping(value = "/addInsurance", method=RequestMethod.POST)
	public ModelAndView savenewInsuree(@ModelAttribute Insurance insurance, BindingResult result){
		ModelAndView mv = new ModelAndView("redirect:/home");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = insuranceservice.saveInsurance(i);
		if (isAdded) {
			System.out.println(i);
			mv.addObject("message", "Applied successfully");
			
		} else {
			return new ModelAndView("error");
		}

		return mv;
		
	}
	@RequestMapping(value = "/calculateInsurance", method = RequestMethod.POST)
	public ModelAndView CalculateInsurance(@ModelAttribute Insurance insurance, BindingResult result){
		ModelAndView mv = new ModelAndView("addInsurance");
		long premium_amount=(insurance.getSum_insured()/insurance.getYear());
		insurance.setPremium_amount(premium_amount);
		double sum_perhectare=premium_amount/insurance.getArea();
		insurance.setSum_perhectare(sum_perhectare);
		long share_premium=(insurance.getPremium_amount()/12);
		insurance.setShare_premium(share_premium);
		insurance.setCompany_name("ICICI");
		i=insurance;
		mv.addObject(insurance);
		return mv;
	}
	@RequestMapping(value="/claim",method=RequestMethod.GET)
	public ModelAndView claimForm(){
		ModelAndView mv=new ModelAndView("claim");
		mv.addObject("headerMessage","details of cause of loss");
		mv.addObject("claim",new Claim());
		return mv;
	}/*
	@RequestMapping(value="/submitclaim",method=RequestMethod.GET)
	public ModelAndView submitclaimForm(){
		ModelAndView mv=new ModelAndView("redirect:/home");
		mv.addObject("headerMessage","details of cause of loss");
		//mv.addObject("claim",new Claim());
		mv.setViewName("claim");
		return mv;
	}*/
	
	@RequestMapping(value="/submitclaim",method=RequestMethod.POST)
	public ModelAndView saveForm(@ModelAttribute Claim claim,BindingResult result){
		ModelAndView mv=new ModelAndView("redirect:/home");
		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = claimservice.addClaim(claim);
		if (isAdded) {
			//mv.addObject("message", "Applied successfully");
			ModelAndView mv1=new ModelAndView("redirect:/home");
			return mv1;
		} else {
			return new ModelAndView("error");
		}

		
	}
}
