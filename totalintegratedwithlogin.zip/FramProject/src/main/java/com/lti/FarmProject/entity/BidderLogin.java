package com.lti.FarmProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BidderLogin1")
public class BidderLogin {
	@Id
	@Column(name = "bidder_id")
	private long bidder_id;
	
	@Column(name = "bpassword")
	private String bpassword;

	public long getBidder_id() {
		return bidder_id;
	}

	public void setBidder_id(long bidder_id) {
		this.bidder_id = bidder_id;
	}

	public String getBpassword() {
		return bpassword;
	}

	public void setBpassword(String bpassword) {
		this.bpassword = bpassword;
	}

	public BidderLogin(long bidder_id, String bpassword) {
		super();
		this.bidder_id = bidder_id;
		this.bpassword = bpassword;
	}

	public BidderLogin() {
		super();
	}

	@Override
	public String toString() {
		return "BidderLogin [bidder_id=" + bidder_id + ", bpassword=" + bpassword + "]";
	}

	
}
