package com.lti.FarmProject.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="claimapp")
public class Claim {
	@Id
	long policy_no;
	String company_name="ICICI";
	String insuree_name;
	long sum_insured;
	String cause_of_loss;
	String period_of_loss;
	Boolean approval_status=false;
	public Claim() {
		super();
	}
	public Claim(String company_name, String insuree_name, long sum_insured, String cause_of_loss,
			String period_of_loss) {
		super();
		this.company_name = company_name;
		this.insuree_name = insuree_name;
		this.sum_insured = sum_insured;
		this.cause_of_loss = cause_of_loss;
		this.period_of_loss = period_of_loss;
	}
	public long getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(long policy_no) {
		this.policy_no = policy_no;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getInsuree_name() {
		return insuree_name;
	}
	public void setInsuree_name(String insuree_name) {
		this.insuree_name = insuree_name;
	}
	public long getSum_insured() {
		return sum_insured;
	}
	public void setSum_insured(long sum_insured) {
		this.sum_insured = sum_insured;
	}
	public String getCause_of_loss() {
		return cause_of_loss;
	}
	public void setCause_of_loss(String cause_of_loss) {
		this.cause_of_loss = cause_of_loss;
	}
	public String getPeriod_of_loss() {
		return period_of_loss;
	}
	public void setPeriod_of_loss(String period_of_loss) {
		this.period_of_loss = period_of_loss;
	}
	public Boolean getApproval_status() {
		return approval_status;
	}
	public void setApproval_status(Boolean approval_status) {
		this.approval_status = approval_status;
	}
	@Override
	public String toString() {
		return "Claim [policy_no=" + policy_no + ", company_name=" + company_name + ", insuree_name=" + insuree_name
				+ ", sum_insured=" + sum_insured + ", cause_of_loss=" + cause_of_loss + ", period_of_loss="
				+ period_of_loss + ", approval_status=" + approval_status + "]";
	}
	
	
}
