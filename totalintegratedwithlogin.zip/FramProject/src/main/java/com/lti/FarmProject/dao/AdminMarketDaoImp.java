package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.AdminMarket;
@Repository("AdminMarketDao")
public class AdminMarketDaoImp  extends AbstractDao<Long, AdminMarket> implements AdminMarketDao{

	
	public List<AdminMarket> getAllMarket() {
		@SuppressWarnings("unchecked")
		List<AdminMarket> amlist=getEntityManager().createQuery("SELECT u FROM AdminMarket u ").getResultList();
		return amlist;
	}

	
	public AdminMarket getMarketById(Long marketid) {
		AdminMarket am=(AdminMarket) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarket u WHERE u.marketid LIKE :Id")
		        .setParameter("Id",marketid)
		        .getSingleResult();
				return am;
	}

	
	public boolean saveMarket(AdminMarket market) {
		persist(market);
		return true;
	}

	
	public boolean deleteMarketById(Long marketid) {
		AdminMarket am=(AdminMarket) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarket u WHERE u.marketid LIKE :Id")
		        .setParameter("Id",marketid)
		        .getSingleResult();
		delete(am);
		return true;
	}


	@Override
	public AdminMarket getMarketByLoc(String loc) {
		// TODO Auto-generated method stub
		AdminMarket am=(AdminMarket) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarket u WHERE u.location LIKE :Id")
		        .setParameter("Id",loc)
		        .getSingleResult();
		return am;
	}


	@Override
	public Boolean updateMarketById(AdminMarket market) {
		// TODO Auto-generated method stub
		try{
			getEntityManager().merge(market);
		}catch(Exception e){
			return false;
		}
		return true;
	}

}
