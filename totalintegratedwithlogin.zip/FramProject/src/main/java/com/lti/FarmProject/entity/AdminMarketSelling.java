package com.lti.FarmProject.entity;

import javax.persistence.Column;
//import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="marketsellingprice")
public class AdminMarketSelling {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="msp-seq")
	@SequenceGenerator(name="msp-seq",sequenceName="msp_seq",allocationSize=1)
	long msp_id;
	@Column(name = "marketid")
	private long marketid;
	@Column(name = "cropname")
	private String cropname;
	@Column(name = "msp")
	private long msp;
	@Column(name="marketlocation")
	String location;
//	@OneToOne
//	@JoinColumn(name ="marketid")
//	private AdminMarket market1;
	public long getMarketid() {
		return marketid;
	}
	public void setMarketid(long marketid) {
		this.marketid = marketid;
	}
	public String getCropname() {
		return cropname;
	}
	public void setCropname(String cropname) {
		this.cropname = cropname;
	}
	public long getMsp() {
		return msp;
	}
	public void setMsp(long msp) {
		this.msp = msp;
	}
//	public AdminMarket getMarket1() {
//		return market1;
//	}
//	public void setMarket1(AdminMarket market1) {
//		this.market1 = market1;
//	}
	
	public AdminMarketSelling(){}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public AdminMarketSelling(String cropname, long msp, String location) {
	super();
	this.cropname = cropname;
	this.msp = msp;
	this.location = location;
}
	public AdminMarketSelling(long marketid, String cropname, long msp, String location) {
	super();
	this.marketid = marketid;
	this.cropname = cropname;
	this.msp = msp;
	this.location = location;
}
	@Override
	public String toString() {
		return "AdminMarketSelling [marketid=" + marketid + ", cropname=" + cropname + ", msp=" + msp + ", location="
				+ location + "]";
	}
	
	
	
	
}
