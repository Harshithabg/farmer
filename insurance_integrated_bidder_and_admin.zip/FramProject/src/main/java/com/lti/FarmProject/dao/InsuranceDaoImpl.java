package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.Insurance;

@Repository("InsuranceDao")
public class InsuranceDaoImpl  extends AbstractDao<Long, Insurance> implements InsuranceDao{

	
	public List<Insurance> getAllInsurances() {
		// TODO Auto-generated method stub
		List<Insurance> il=getEntityManager().createQuery("SELECT u FROM Insurance u ").getResultList();
		return il;
	}

	//@Override
	public Insurance getInsuranceByPolicy(long policy_no) {
		// TODO Auto-generated method stub
		Insurance ins=(Insurance) getEntityManager()
                .createQuery("SELECT u FROM Insurance u WHERE u.policy_no LIKE :Id")
                .setParameter("Id",policy_no)
                .getSingleResult();
		return ins;
	}

	//@Override
	public Boolean saveInsurance(Insurance insurance) {
		// TODO Auto-generated method stub
		persist(insurance);
		return true;
	}

	//@Override
	public Boolean deleteInsuranceByPolicy(long policy_no) {
		// TODO Auto-generated method stub
		Insurance ins=(Insurance) getEntityManager()
                .createQuery("SELECT u FROM Insurance u WHERE u.policy_no LIKE :Id")
                .setParameter("Id",policy_no)
                .getSingleResult();
		delete(ins);
		return true;
	}

}
