package com.lti.FarmProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FarmerLogin2")
public class FarmerLogin {

	@Id
	@Column(name = "farmer_id")
	public long farmer_id;
	
	@Column(name = "fpassword")
	public  String fpassword;

	public long getFarmer_id() {
		return farmer_id;
	}

	public void setFarmer_id(long farmer_id) {
		this.farmer_id = farmer_id;
	}

	public String getFpassword() {
		return fpassword;
	}

	public void setFpassword(String fpassword) {
		this.fpassword = fpassword;
	}

	public FarmerLogin(long farmer_id, String fpassword) {
		super();
		this.farmer_id = farmer_id;
		this.fpassword = fpassword;
	}
	

	public FarmerLogin() {
		super();
	}

	@Override
	public String toString() {
		return "FarmerLogin [farmer_id=" + farmer_id + ", fpassword=" + fpassword + "]";
	}
	
	
}