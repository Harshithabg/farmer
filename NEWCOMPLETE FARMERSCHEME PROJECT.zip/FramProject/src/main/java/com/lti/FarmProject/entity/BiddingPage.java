package com.lti.FarmProject.entity;

//import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="biddingpage22")
public class BiddingPage {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bid-seq")
	@SequenceGenerator(name="bid-seq",sequenceName="bid1_seq",allocationSize=1)
	long bid_id;
	//long bidder_id;
	//String date;
	String bid_crop_type;
	long bid_requestid;
	long bid_quantity;
	long bid_price;
	String bid_crop_name;
//	@OneToOne(cascade=CascadeType.ALL)
//	@JoinColumn(name="requestid")
//	FarmerPlaceRequest selling_req;
//	//Bidder bidder;
	long bid_your_amount;
	long current_bid;
	Boolean finalbid;
	public BiddingPage() {
		super();
	}

//	public BiddingPage (String date) {//(long bidder_id,, Bidder bidder FarmerPlaceRequest selling_req
//		super();
//		//this.bidder_id = bidder_id;
//		this.date = date;
//		//this.selling_req = selling_req;
//		//this.bidder = bidder;
//	}
	
	public BiddingPage(String bid_crop_type, long bid_requestid, long bid_quantity, long bid_price,
			String bid_crop_name) {
		super();
		this.bid_crop_type = bid_crop_type;
		this.bid_requestid = bid_requestid;
		this.bid_quantity = bid_quantity;
		this.bid_price = bid_price;
		this.bid_crop_name = bid_crop_name;
	}
	
	public BiddingPage(String bid_crop_type, long bid_requestid, long bid_quantity, long bid_price,
			String bid_crop_name, long bid_your_amount, long current_bid, Boolean finalbid) {
		super();
		this.bid_crop_type = bid_crop_type;
		this.bid_requestid = bid_requestid;
		this.bid_quantity = bid_quantity;
		this.bid_price = bid_price;
		this.bid_crop_name = bid_crop_name;
		this.bid_your_amount = bid_your_amount;
		this.current_bid = current_bid;
		this.finalbid = finalbid;
	}

	public BiddingPage(long bid_id, String bid_crop_type, long bid_requestid, long bid_quantity, long bid_price,
			String bid_crop_name, long bid_your_amount, long current_bid, Boolean finalbid) {
		super();
		this.bid_id = bid_id;
		this.bid_crop_type = bid_crop_type;
		this.bid_requestid = bid_requestid;
		this.bid_quantity = bid_quantity;
		this.bid_price = bid_price;
		this.bid_crop_name = bid_crop_name;
		this.bid_your_amount = bid_your_amount;
		this.current_bid = current_bid;
		this.finalbid = finalbid;
	}

	public Boolean getFinalbid() {
		return finalbid;
	}

	public void setFinalbid(Boolean finalbid) {
		this.finalbid = finalbid;
	}

	public BiddingPage(String bid_crop_type, long bid_requestid, long bid_quantity, long bid_price, String bid_crop_name,
		long bid_your_amount, long current_bid) {
	super();
	this.bid_crop_type = bid_crop_type;
	this.bid_requestid = bid_requestid;
	this.bid_quantity = bid_quantity;
	this.bid_price = bid_price;
	this.bid_crop_name = bid_crop_name;
	this.bid_your_amount = bid_your_amount;
	this.current_bid = current_bid;
}

	public long getBid_id() {
		return bid_id;
	}

	public void setBid_id(long bid_id) {
		this.bid_id = bid_id;
	}
/*
	public long getBidder_id() {
		return bidder_id;
	}

	public void setBidder_id(long bidder_id) {
		this.bidder_id = bidder_id;
	}
*/
//	public String getDate() {
//		return date;
//	}
//
//	public void setDate(String date) {
//		this.date = date;
//	}

//	public FarmerPlaceRequest getSelling_req() {
//		return selling_req;
//	}
//
//	public void setSelling_req(FarmerPlaceRequest selling_req) {
//		this.selling_req = selling_req;
//	}
	/*
	public Bidder getBidder() {
		return bidder;
	}

	public void setBidder(Bidder bidder) {
		this.bidder = bidder;
	}*/
	
	public long getCurrent_bid() {
		return current_bid;
	}

	public void setCurrent_bid(long current_bid) {
		this.current_bid = current_bid;
	}

	public long getBid_your_amount() {
		return bid_your_amount;
	}

	public void setBid_your_amount(long bid_your_amount) {
		this.bid_your_amount = bid_your_amount;
	}
	
	public String getBid_crop_type() {
		return bid_crop_type;
	}

	public void setBid_crop_type(String bid_crop_type) {
		this.bid_crop_type = bid_crop_type;
	}

	public long getBid_requestid() {
		return bid_requestid;
	}

	public void setBid_requestid(long bid_requestid) {
		this.bid_requestid = bid_requestid;
	}

	public long getBid_quantity() {
		return bid_quantity;
	}

	public void setBid_quantity(long bid_quantity) {
		this.bid_quantity = bid_quantity;
	}

	public long getBid_price() {
		return bid_price;
	}

	public void setBid_price(long bid_price) {
		this.bid_price = bid_price;
	}

	public String getBid_crop_name() {
		return bid_crop_name;
	}

	public void setBid_crop_name(String bid_crop_name) {
		this.bid_crop_name = bid_crop_name;
	}
	
	@Override
	public String toString() {
		return "BiddingPage [bid_id=" + bid_id + ", bid_crop_type=" + bid_crop_type + ", bid_requestid=" + bid_requestid
				+ ", bid_quantity=" + bid_quantity + ", bid_price=" + bid_price + ", bid_crop_name=" + bid_crop_name
				+ ", bid_your_amount=" + bid_your_amount + ", current_bid=" + current_bid + "]";
	}

	
	
	
	

}