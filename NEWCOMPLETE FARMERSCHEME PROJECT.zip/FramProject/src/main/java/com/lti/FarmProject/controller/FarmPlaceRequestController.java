package com.lti.FarmProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.service.FarmerPlaceRequestService;

@Controller
public class FarmPlaceRequestController {
	private FarmerPlaceRequestService userService;

	public FarmPlaceRequestController() {

	}
	@Autowired
	public FarmPlaceRequestController(FarmerPlaceRequestService userService) {
		this.userService = userService;
	}


	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("newhome");
		return mv;
	}
	@RequestMapping(value = { "/farmerhome" }, method = RequestMethod.GET)
	public ModelAndView farmerhome(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView("farmerhome");
		mv.setViewName("farmerhome");
		return mv;
	}
	@RequestMapping(value = { "/farmerbidding" }, method = RequestMethod.GET)
	public ModelAndView farmerbidding(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView("farmerbidding");
		mv.setViewName("farmerbidding");
		return mv;
	}
	@RequestMapping(value ="/adminhome", method = RequestMethod.POST)
	public ModelAndView admin(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/adminhome1");
		return mv;
	}
	
	@RequestMapping(value = "/allUsers", method = RequestMethod.GET)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<FarmerPlaceRequest> userList = userService.getAllPlaceRequest();
		mv.addObject("userList", userList);
		mv.setViewName("allUsers");
		return mv;
	}
	

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("addUser");
		mv.addObject("headerMessage", "Add Place Request");
		mv.addObject("request", new FarmerPlaceRequest());
		return mv;
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute FarmerPlaceRequest request, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/farmerhome");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = userService.savePlaceRequest(request);
		if (isAdded) {
			mv.addObject("message", "New place request successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/editUser/{requestid}", method = RequestMethod.GET)
	public ModelAndView displayEditUserForm(@PathVariable Long requestid) {
		ModelAndView mv = new ModelAndView("/editUser");
		FarmerPlaceRequest request = userService.getPlaceRequestById(requestid);
		mv.addObject("headerMessage", "Edit Place Request Details");
		mv.addObject("request", request);
		return mv;
	}

	@RequestMapping(value = "/editUser/{requestid}", method = RequestMethod.POST)
	public ModelAndView saveEditedUser(@ModelAttribute FarmerPlaceRequest request, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/home");

		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		boolean isSaved = userService.updatePlaceRequestById(request);
		if (!isSaved) {

			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/deleteUser/{requestid}", method = RequestMethod.GET)
	public ModelAndView deleteUserById(@PathVariable Long requestid) {
		boolean isDeleted = userService.deletePlaceRequestById(requestid);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/home");
		return mv;

	}
	
}
