package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.dao.BidderDao;
import com.lti.FarmProject.entity.Bidder;
//import com.lti.FarmProject.entity.BiddingPage;
//import com.lti.FarmProject.entity.Farmer;

@Service
@Transactional
public class BidderServiceImp implements BidderService {
	
private BidderDao dao;
	
	public BidderServiceImp() {
		
	}
	
	@Autowired
	public BidderServiceImp(BidderDao dao) {
		super();
		this.dao = dao;
	}
	@Override
	public List<Bidder> getAllBidders() {
		List<Bidder> list = new ArrayList<Bidder>();
		list=dao.getAllBidders();
		return list;
	}

	@Override
	public Bidder getBiddersById(String bidder_id) {
		Bidder bidder =  dao.getBiddersById(bidder_id);
		return bidder;
	}

	@Override
	public boolean saveBidders(Bidder bidder) {
		try {
			dao.saveBidders(bidder);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteBiddersById(Long bidder_id) {
		try {
			dao.deleteBiddersById(bidder_id);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public Boolean verifybidderbyId(long id, String password) {
		// TODO Auto-generated method stub
		dao.verifybidderrbyId(id, password);
		return null;
	}

	@Override
	public Boolean updatebidder(Bidder b) {
		// TODO Auto-generated method stub
		dao.updatebidder(b);
		return true;
	}

	@Override
	public Bidder getBiddersusingId(Long bidder_id) {
		// TODO Auto-generated method stub
		Bidder b=dao.getBiddersusingId(bidder_id);
		return b;
	}

	
	}


