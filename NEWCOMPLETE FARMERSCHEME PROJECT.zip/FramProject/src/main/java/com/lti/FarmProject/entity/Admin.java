package com.lti.FarmProject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Admin123")
public class Admin {
	@Id
	@Column(name = "admin_id")
	private long admin_id;
	
	@Column(name = "password")
	private String password;

	public Admin(long admin_id, String password) {
		super();
		this.admin_id = admin_id;
		this.password = password;
	}

	public long getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(long admin_id) {
		this.admin_id = admin_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [admin_id=" + admin_id + ", password=" + password + "]";
	}
	
	
	
}
