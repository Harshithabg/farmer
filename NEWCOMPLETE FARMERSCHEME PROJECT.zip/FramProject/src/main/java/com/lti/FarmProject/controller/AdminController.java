package com.lti.FarmProject.controller;

import java.io.IOException;
import java.util.List;

import javax.jws.WebParam.Mode;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.Bidder;
//import com.lti.FarmProject.entity.AdminMarketSelling;
import com.lti.FarmProject.entity.BiddingPage;
import com.lti.FarmProject.entity.Claim;
import com.lti.FarmProject.entity.Farmer;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.service.BidderService;
import com.lti.FarmProject.service.BiddingPageService;
import com.lti.FarmProject.service.ClaimService;
import com.lti.FarmProject.service.FarmerPlaceRequestService;
import com.lti.FarmProject.service.FarmerService;

@Controller
public class AdminController {
	@Autowired
	private BiddingPageService service;
	@Autowired
	private FarmerPlaceRequestService userService;
	@Autowired
	private ClaimService cs;
	@Autowired
	private FarmerService fs;
	@Autowired
	private BidderService bs;
	
	public AdminController() {
		super();
	}

	public AdminController(BiddingPageService service) {
		super();
		this.service = service;
	}
	
	public AdminController(ClaimService cs) {
		super();
		this.cs = cs;
	}

	public AdminController(FarmerService fs) {
		super();
		this.fs = fs;
	}

	public AdminController(BidderService bs) {
		super();
		this.bs = bs;
	}

	public AdminController(FarmerPlaceRequestService userService) {
		super();
		this.userService = userService;
	}
	long req_id;
	BiddingPage bidding;
	FarmerPlaceRequest fpm;
	@RequestMapping(value="/adminbids",method=RequestMethod.GET)
	public ModelAndView getBindingPage(){
		ModelAndView mv=new ModelAndView("adminbiddingdetails");
		List<BiddingPage> sellreq= service.getallbids();
		mv.addObject("sellreq",sellreq);
		return mv;
	}
	@RequestMapping(value = "/allsellreq", method = RequestMethod.GET)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<FarmerPlaceRequest> userList = userService.getAllPlaceRequest();
		mv.addObject("userList", userList);
		mv.setViewName("adminsellreq");
		return mv;
	}
	@RequestMapping(value = { "/adminhome1" }, method = RequestMethod.GET)
	public ModelAndView hello(@RequestParam("admin_id") String id,@RequestParam("password")String pass) {
		ModelAndView mv = new ModelAndView();
		if(id.equals(pass)){
		mv.setViewName("adminhome1");
		return mv;
		}
		else
		return new ModelAndView("adminlog");	
		
	}
	@RequestMapping(value={"/claimdetails"},method=RequestMethod.GET)
	public ModelAndView claims(){
		ModelAndView mv=new ModelAndView("adminclaimdetails");
		List<Claim> cl=cs.getAllClaims();
		//mv.addObject("claims", claims);
		System.out.println(cl);
		mv.addObject("claims", cl);
		mv.setViewName("adminclaimdetails");
		return mv;
	}
	@RequestMapping(value = "/approveclaims/{policy_no}", method = RequestMethod.GET)
	public ModelAndView getclaimForm(@PathVariable Long policy_no) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");
		Claim c=cs.getClaimForm(policy_no);
		
		//c.setApproval_status(true);
		cs.updateclaim(c, true);
		mv.addObject("headerMessage", "Approve Claims");
		mv.addObject("claims", c);
		return mv;
	}

/*	@RequestMapping(value = "/approveclaims/{policy_no}", method = RequestMethod.POST)
	public ModelAndView saveEditedUser(@ModelAttribute Claim c, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");

		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		
		try{
			boolean isSaved = cs.updateclaim(c, true);
		}catch(Exception e){
			return new ModelAndView("error");
		}


		return mv;
	}*/
	@RequestMapping(value = "/deleteclaims/{policy_no}", method = RequestMethod.GET)
	public ModelAndView deleteclaimById(@PathVariable long policy_no) {
		boolean isDeleted = cs.deleteclaim(policy_no);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/adminsell");
		return mv;

	}
	@RequestMapping(value="/finalise/{bid_id}",method = RequestMethod.GET)
	public ModelAndView finalisebids(@PathVariable long bid_id){
		ModelAndView mv=new ModelAndView("adminhome1");
		BiddingPage b=service.getbidbyid(bid_id);
		b.setFinalbid(true);
		service.updateBiddingPage(b);
		mv.setViewName("adminhome1");
		return mv;
		
	}
	@RequestMapping(value="/adminverify",method=RequestMethod.GET)
	public ModelAndView display(){
		ModelAndView mv=new ModelAndView("adminverify");
		return mv;
	}
	@RequestMapping(value = "/approvefarmer/{farmer_id}", method = RequestMethod.GET)
	public ModelAndView getfarmer(@PathVariable Long farmer_id) {
		ModelAndView mv = new ModelAndView("redirect:/adminverify");
		Farmer f= fs.getFarmerusingId(farmer_id);
		f.setVerified(true);
		//c.setApproval_status(true);
		fs.updatefarmer(f);
		mv.addObject("headerMessage", "Approve Claims");
		mv.addObject("claims", f);
		return mv;
	}
	@RequestMapping(value = "/deletefarmer/{farmer_id}", method = RequestMethod.GET)
	public ModelAndView deletefarmer(@PathVariable Long farmer_id) {
		ModelAndView mv = new ModelAndView("redirect:/adminverify");
		Farmer f= fs.getFarmerusingId(farmer_id);
		f.setVerified(true);
		long id=f.getFarmer_id();
		//c.setApproval_status(true);
		fs.deleteFarmersById(id);
		mv.addObject("headerMessage", "Approve Claims");
		mv.addObject("claims", f);
		return mv;
	}
	@RequestMapping(value="/farmerlist",method=RequestMethod.GET)
	public ModelAndView farmerlist(){
		ModelAndView mv=new ModelAndView("farmerlist");
		List<Farmer> fl=fs.getAllFarmers();
		//mv.addObject("claims", claims);
		System.out.println(fl);
		mv.addObject("claims", fl);
		mv.setViewName("farmerlist");
		return mv;
	}
	@RequestMapping(value = "/approvebidder/{bidder_id}", method = RequestMethod.GET)
	public ModelAndView getbidder(@PathVariable Long bidder_id) {
		ModelAndView mv = new ModelAndView("redirect:/adminverify");
		Bidder b=bs.getBiddersusingId(bidder_id);
		b.setVerified(true);
		//c.setApproval_status(true);
		bs.updatebidder(b);
		mv.addObject("headerMessage", "Approve Claims");
		mv.addObject("claims",b);
		return mv;
	}
	@RequestMapping(value = "/deletebidder/{bidder_id}", method = RequestMethod.GET)
	public ModelAndView deletebidder(@PathVariable Long bidder_id) {
		ModelAndView mv = new ModelAndView("redirect:/adminverify");
		Bidder b=bs.getBiddersusingId(bidder_id);
		b.setVerified(true);
		long id=b.getBidder_id();
		//c.setApproval_status(true);
		fs.deleteFarmersById(id);
		mv.addObject("headerMessage", "Approve Claims");
		mv.addObject("claims", b);
		return mv;
	}
	@RequestMapping(value="/bidderlist",method=RequestMethod.GET)
	public ModelAndView bidderlist(){
		ModelAndView mv=new ModelAndView("bidderlist");
		List<Bidder> fl=bs.getAllBidders();
		//mv.addObject("claims", claims);
		System.out.println(fl);
		mv.addObject("claims", fl);
		mv.setViewName("bidderlist");
		return mv;
	}
}

