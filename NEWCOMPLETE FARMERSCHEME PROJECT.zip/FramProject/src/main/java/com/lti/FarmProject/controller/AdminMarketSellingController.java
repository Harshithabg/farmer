package com.lti.FarmProject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.AdminMarketSelling;

import com.lti.FarmProject.service.AdminMarketSellingService;



@Controller
public class AdminMarketSellingController {
	private AdminMarketSellingService userService;

	public AdminMarketSellingController() {

	}
	@Autowired
	public AdminMarketSellingController(AdminMarketSellingService userService) {
		this.userService = userService;
	}
	
	@RequestMapping(value = { "/", "/adminsell" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminhome1");
		return mv;
	}
	@RequestMapping(value = { "/adminlogin" }, method = RequestMethod.GET)
	public ModelAndView adminhello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("adminlog");
		return mv;
	}
//	@RequestMapping(value = { "/adminhome" }, method = RequestMethod.GET)
//	public ModelAndView adminhome(HttpServletResponse response) throws IOException {
//		ModelAndView mv = new ModelAndView();
//		mv.setViewName("adminhome");
//		return mv;
//	}
	
	@RequestMapping(value = "/allMarketSellings", method = RequestMethod.GET)
	public ModelAndView displayAllUser() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView("allMarketSellings");
		List<AdminMarketSelling> userList = userService.getAllMarketSelling();
		mv.addObject("userList", userList);
		mv.setViewName("allMarketSellings");
		return mv;
	}
	
	@RequestMapping(value = "/viewmarketplace", method = RequestMethod.GET)
	public ModelAndView displayAllUser1() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView("viewmarketplace");
		List<AdminMarketSelling> marketlist = userService.getAllMarketSelling();
//		System.out.println(userList);
		mv.addObject("marketlist", marketlist);
		
		mv.setViewName("viewmarketplace");
		return mv;
	}
	
	@RequestMapping(value = "/addMarketSelling", method = RequestMethod.GET)
	public ModelAndView displayNewUserForm() {
		ModelAndView mv = new ModelAndView("addMarketSelling");
		mv.addObject("headerMessage", "Add User Details");
		mv.addObject("marketsell", new AdminMarketSelling());
		return mv;
	}

	@RequestMapping(value = "/saveMarketSelling", method = RequestMethod.POST)
	public ModelAndView saveNewUser(@ModelAttribute AdminMarketSelling marketsell, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = userService.saveMarketSelling(marketsell);
		if (isAdded) {
			mv.addObject("message", "New user successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	}
	@RequestMapping(value = "/editMarketSelling/{msp_id}", method = RequestMethod.GET)
	public ModelAndView displayEditUserForm(@PathVariable Long msp_id) {
		ModelAndView mv = new ModelAndView("/editMarketSelling");
		AdminMarketSelling marketsell = userService.getMarketSellingById(msp_id);
		mv.addObject("headerMessage", "Edit User Details");
		mv.addObject("marketsell", marketsell);
		return mv;
	}

	@RequestMapping(value = "/editMarketSelling/{msp_id}", method = RequestMethod.POST)
	public ModelAndView saveEditedUser(@ModelAttribute AdminMarketSelling marketsell, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/adminsell");

		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		boolean isSaved = userService.updateMarketSellingById(marketsell);
		if (!isSaved) {

			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/deleteMarketSelling/{msp_id}", method = RequestMethod.GET)
	public ModelAndView deleteUserById(@PathVariable long msp_id) {
		boolean isDeleted = userService.deleteMarketSellingById(msp_id);
		System.out.println("User deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/adminsell");
		return mv;

	}

}
